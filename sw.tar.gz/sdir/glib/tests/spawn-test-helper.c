#include <stdio.h>

int main (void)
{
  fprintf (stderr, "this is spawn-test-helper from glib/tests\n");
  return 0;
}
